from flask import Flask  #importing flask class

app = Flask(__name__) 
#__name__ is a variable name of the module
#creating an instance

# app.debug = True

@app.route("/home")
@app.route("/") 
#decorator adds backend and abstracts??
def home(): #page
    return "<h2>Home Page</h2>"
    # return "first       ljc <h1>html tagss </h1>"#only one space is displayed


@app.route("/about")
def about():
    return "About Page"


if __name__ == "__main__":
    app.run(debug=True)
    #runs only if directly called using python fblog.py


# running using enviroment variables everytime have to be set after shutdowm
# set FLASK_APP=fblog.py
# set FLASK_DEBUG=1
# flask run